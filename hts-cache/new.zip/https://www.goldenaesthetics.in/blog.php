<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="shortcut icon" href="images/Favicon.png" type="image/x-icon">

        <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-K294KMM');</script>
<!-- End Google Tag Manager -->
       
          <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <base href="https://www.goldenaesthetics.in/"> 
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
       
        
          <title>Golden Aesthetics Blog - News, Facts, Surgery Details, and much more</title>
     
        <link rel="canonical" href="https://www.goldenaesthetics.in/blog" />
        <meta name="description" content="Golden Aesthetics Blogs includes information about different types of surgeries provided here. We also share interesting facts and the latest news of surgery.">
       
        <!-- <link rel="stylesheet" href="css/bootstrap.min.css" /> -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"  >
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/css2?family=Jost:wght@400;700&display=swap" rel="stylesheet" />
  
        <link  href="https://unpkg.com/swiper/swiper-bundle.css" rel="stylesheet" />
        <link href="css/style.css" rel="stylesheet"  />
        <link rel="stylesheet" href="venobox/venobox.css" type="text/css" media="screen" />
        <meta name="google-site-verification" content="ans6A_gJT0OsqcZWGsJAYmLtDkwtc95BJIyL1o8p4aU" />
       <!-- Meta Og Tags-->
       
       <meta property="og:locale" content="en_US" />
 <meta property="og:title" content="Best Hair Transplant for Women in India - Golden Aesthetics" />
   <meta property="og:description" content="Worried about hair loss? Visit the Golden esthetics hair transplant clinic in Amritsar and get the best solution for hair loss from an experienced doctor." />
     <meta property="og:url" content="https://www.goldenaesthetics.in/" />
   <meta property="og:site_name" content="Golden Aesthetics" />
 <meta property="og:type" content="website" />
 <meta property="fb:app_id" content="" />
   <meta property="og:image" content="" />
 <meta property="og:image:secure_url" content="" />
 <meta property="og:image:width" content="1600" />
 <meta property="og:image:height" content="660" />
       
       
       <!--End Meta Og Tags-->
        
        
        
        <!-- Global site tag (gtag.js) - Google Analytics -->

<script type='application/ld+json'>
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Golden Aesthetics",
  "image": "https://goldenaesthetics.in/images/banner2.png",
  "@id": "",
  "url": "https://www.goldenaesthetics.in/",
  "telephone": "8070500900",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "Golden Aesthetics Above Charming Chicken, Majitha Rd, Sehaj Avenue",
    "addressLocality": "Amritsar",
    "postalCode": "143001",
    "addressCountry": "IN"
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "5",
    "reviewCount": "250"
  },
  "openingHoursSpecification": {
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": [
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday"
    ],
    "opens": "09:30",
    "closes": "07:30"
  },
  "sameAs": [
    "https://www.facebook.com/goldenaestheticsamritsar/",
    "https://www.instagram.com/goldenaestheticsamritsar/"
  ]
}
</script>






    </head>
    <style type="text/css">
    @media (min-width: 1024px)
    {
.monaka-menu-item>a span {
    font-family: "Jost",sans-serif;
    color: #002c56;
    font-weight: 700;
}}
        #myBtn {
           width: 45px;
    display: none;
    position: fixed;
    bottom: 20px;
    right: 30px;
    z-index: 9999;
    font-size: 18px;
    border: 2 px solid #f4ca01;
    outline: none;
    background-color: #f4ca01;
    color: white;
    cursor: pointer;
    padding: 7px;
    border-radius: 26px;
}




#myBtn:hover {
  background-color: #eef0e4;
}
        #Beard_Transplant, #Eyebrow_Transplant, #Women_Hair_Transplant, #Men_Hair_Transplant {
            display: none;
        }
        @media only screen 
and (min-device-width : 360px)   
and (max-device-width : 480px)  
{ 
   .gapple {
    display:none;
}
}
        
        
        
        
            @media only screen 
and (min-device-width : 360px)   
and (max-device-width : 480px)  
{ 
 .ti
 {
     margin-top: 0px;"
     
 }
}
    @media only screen 
and (min-device-width : 481px)   
and (max-device-width : 2800px)  
{ 
 .ti
 {
     margin-top: -56px;"
     
 }
}
    </style>
    <body>
       
        <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-K294KMM"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
        <button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fa fa-arrow-up" style="color:#000;"></i></button>
        <section class="header">
            <div class="topbar">
                <div class="container">
                    <div class="row">
                        <div class="col-md-5">
                            <ul class="contact-detail">
                                <li class="">
                                    <a href="tel:918070500900">
                                        <span><ion-icon name="call-outline"></ion-icon> </span> +91 - 8070500900
                                    </a>
                                </li>
                                <li class="">
                                    <a href="">
                                        <span><ion-icon name="time-outline"></ion-icon></span> Mon - Sat 09:30 AM to 07:30 PM
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-2">
                           <!-- <a href="https://www.goldenaesthetics.in/" class="logo">
                                <img src="logo/goldenae.png" alt="LOGO" style="margin-top: -24px;
    width: 88px;";/>
                            </a>-->
                        </div>
                        <div class="col-md-5">
                            <ul class="contact-detail">
                                <li class="float-end">
                                    <a href="mailto:goldenaesthetics999@gmail.com">
                                        <span> <ion-icon name="mail-outline"></ion-icon> </span> goldenaesthetics999@gmail.com
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <header class="monaka-header monaka-header-center-1 ti" role="banner" > 
                <div class="monaka-container monaka-flex   lg:monaka-align-center">
                    <!-- MOBILE MENU TOGGLE -->
                   <!--  <div class="monaka-menu-toggler monaka-mobile-only">
                        <label for="MONAKA-NAV">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                <path d="M3 18h12v-2H3v2zM3 6v2h18V6H3zm0 7h18v-2H3v2z"></path>
                                <path fill="none" d="M0 0h24v24H0V0z"></path>
                            </svg>
                        </label>
                    </div> -->
                    <!-- MOBILE MENU TOGGLE END -->

                    <!-- MOBILE LOGO -->
                    <div class="monaka-logo  monaka-mobile-only" style='margin-left: 0px !important;'  > 
                        <h1>
        <a href="#" title="Golden Aesthetiics">
          <img src="logo/golden.png" alt="GOlden Aesthetics" class="monaka-logo-light">
          <img src="logo/golden.png" alt="GOlden Aesthetics" class="monaka-logo-dark">
          
        </a>
        
      </h1>
                    </div>
                    <!-- MOBILE LOGO END -->

                    <div class="monaka-flex monaka-align-middle" >
                        <input type="checkbox" id="MONAKA-NAV" class="monaka-menu-monitor monaka-hidden" />
                        <label for="MONAKA-NAV" class="monaka-menu-overlay"></label>

                        <!-- MONAKA MENU -->
                        <nav class="monaka-menu" role="navigation">
                            <ul class="monaka-menu-title">
                                <li>
                                    <!-- MOBILE MENU TOGGLE -->
                                   
                                    <!-- MOBILE MENU TOGGLE END -->

                                    <!-- MOBILE LOGO -->
                                      <div class="monaka-logo">
              <h1>
                <a href="#" title="Golden Aesthetics">
                  <img src="images/logo.png"  alt="GOlden Aesthetics" class="monaka-logo-light">
                  <img src="images/logo.png"  alt="GOlden Aesthetics" class="monaka-logo-dark">
                  
                </a>
                
              </h1>
            </div>
                                    <!-- MOBILE LOGO END -->
                                </li>
                            </ul>
                            <ul class="monaka-menu-body monaka-menu-body-center">
                                <li>
                                    <ul>
                                        <li class="monaka-menu-item monaka-menu-active">
                                            <a href="https://www.goldenaesthetics.in/"><i class="fas fa-home"></i> <span>Home</span></a>
                                        </li>
                                        <li class="monaka-menu-item">
                                            <a href="about-us"><i class="fas fa-home"></i> <span>About Us</span></a>
                                        </li>
                                     <!--    <li class="monaka-menu-item">
                                            <a href="service.php"><i class="fas fa-shipping-fast"></i> <span>Services</span> </a>
                                        </li> -->

                                        <li class="monaka-menu-item ">
                                            <a href="service"><i class="fas fa-comment-dots"></i> <span>Services</span> <span class="monaka-menu-arrow"></span></a>

                                            <ul>
                                                   

                                                                                    <li class="monaka-menu-item">
                                                                                <a href="javascript:void(0);"> <span style="color: #000000;
    font-weight: 700;">Surgical</span><span class="monaka-menu-arrow"></span> </a>
                                                                                <ul>
                                                                                                                                                                        <li id="Hair_Transplant"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                         <a href="javascript:void(0);" sub="1"><span> Hair Transplant </span></a>
                                         

                                                                                                                                                                          <span class="monaka-menu-arrow monaka-submenu-open"></span>

                                                                    <ul style="display: revert;">
                                                                                                                                                 <li  class="monaka-menu-item"> <a href="services_detail/best-hair-transplant-clinic-in-punjab" sub="1"><span style="color: #000000;
    font-weight: 700;">Hair Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/beard-transplant-in-india" sub="1"><span style="color: #000000;
    font-weight: 700;">Beard Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/eyebrow-transplant-in-india" sub="1"><span style="color: #000000;
    font-weight: 700;">Eyebrow Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/hair-transplant-for-women-in-india" sub="1"><span style="color: #000000;
    font-weight: 700;">Women Hair Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/hair-transplant-for-mens" sub="1"><span style="color: #000000;
    font-weight: 700;">Men Hair Transplant</span></a></li>

                                                                                                                                        </ul>
                                                            </li>                                                                                    <li id="Dimple_Creation"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/dimple-creation-in-india" sub="3"><span>  Dimple Creation                                                 </span></a>                                 

                                                                                                                                                                                          <li id="Rhinoplasty_Surgery"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/nose-plastic-surgery-in-india" sub="5"><span>  Rhinoplasty Surgery                                                 </span></a>                                 

                                                                                                                                                                                          <li id="Eyelid_Surgery"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/eyelid-plastic-surgery" sub="6"><span>  Eyelid Surgery                                                 </span></a>                                 

                                                                                                                                                                                          <li id="Body_Contouring"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/body-contouring-surgery-in-india" sub="7"><span>  Body Contouring                                                 </span></a>                                 

                                                                                                                                                                                          <li id="Gynaecomastia"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/best-gynecomastia-surgery-in-india" sub="8"><span>  Gynaecomastia                                                 </span></a>                                 

                                                                                                                                                                                          <li id="Liposuction"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/best-liposuction-surgery-in-india" sub="9"><span>  Liposuction                                                 </span></a>                                 

                                                                                                                                                                                          <li id="Hymenoplasty"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/hymenoplasty-surgery-in-india" sub="11"><span>  Hymenoplasty                                                 </span></a>                                 

                                                                                                                                                                                          <li id="Scar_Revision"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/plastic-surgery-for-scars-on-face" sub="12"><span>  Scar Revision                                                 </span></a>                                 

                                                                                                                                                                                          <li id="Otoplasty"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/otoplasty-surgery-in-india" sub="13"><span>  Otoplasty                                                 </span></a>                                 

                                                                                                                                                                                          <li id="Tummy_Tuck"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/tummy-tuck-in-india" sub="24"><span>  Tummy Tuck                                                 </span></a>                                 

                                                                                                                                                                                          <li id="Auroplasty"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/face-split-earlobe-repair-in-india" sub="4"><span>  Auroplasty                                                 </span></a>                                 

                                                                                                                                                                                          <li id="Face_Lift_Surgery"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/face-lift-plastic-surgery-in-india" sub="2"><span>  Face Lift Surgery                                                 </span></a>                                 

                                                                                                                                                                                          <li id="Breast_Augmentation"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/breast-augmentation-surgery-in-india" sub="23"><span>  Breast Augmentation                                                 </span></a>                                 

                                                                                                                                                                                          <li id="Beard_Transplant"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/beard-transplant-in-india" sub="1"><span>  Beard Transplant                                                 </span></a>                                 

                                                                                                                                                                          <span class="monaka-menu-arrow monaka-submenu-open"></span>

                                                                    <ul style="display: revert;">
                                                                                                                                                 <li  class="monaka-menu-item"> <a href="services_detail/best-hair-transplant-clinic-in-punjab" sub="1"><span style="color: #000000;
    font-weight: 700;">Hair Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/beard-transplant-in-india" sub="1"><span style="color: #000000;
    font-weight: 700;">Beard Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/eyebrow-transplant-in-india" sub="1"><span style="color: #000000;
    font-weight: 700;">Eyebrow Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/hair-transplant-for-women-in-india" sub="1"><span style="color: #000000;
    font-weight: 700;">Women Hair Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/hair-transplant-for-mens" sub="1"><span style="color: #000000;
    font-weight: 700;">Men Hair Transplant</span></a></li>

                                                                                                                                        </ul>
                                                            </li>                                                                                    <li id="Eyebrow_Transplant"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/eyebrow-transplant-in-india" sub="1"><span>  Eyebrow Transplant                                                 </span></a>                                 

                                                                                                                                                                          <span class="monaka-menu-arrow monaka-submenu-open"></span>

                                                                    <ul style="display: revert;">
                                                                                                                                                 <li  class="monaka-menu-item"> <a href="services_detail/best-hair-transplant-clinic-in-punjab" sub="1"><span style="color: #000000;
    font-weight: 700;">Hair Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/beard-transplant-in-india" sub="1"><span style="color: #000000;
    font-weight: 700;">Beard Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/eyebrow-transplant-in-india" sub="1"><span style="color: #000000;
    font-weight: 700;">Eyebrow Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/hair-transplant-for-women-in-india" sub="1"><span style="color: #000000;
    font-weight: 700;">Women Hair Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/hair-transplant-for-mens" sub="1"><span style="color: #000000;
    font-weight: 700;">Men Hair Transplant</span></a></li>

                                                                                                                                        </ul>
                                                            </li>                                                                                    <li id="Women_Hair_Transplant"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/hair-transplant-for-women-in-india" sub="1"><span>  Women Hair Transplant                                                 </span></a>                                 

                                                                                                                                                                          <span class="monaka-menu-arrow monaka-submenu-open"></span>

                                                                    <ul style="display: revert;">
                                                                                                                                                 <li  class="monaka-menu-item"> <a href="services_detail/best-hair-transplant-clinic-in-punjab" sub="1"><span style="color: #000000;
    font-weight: 700;">Hair Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/beard-transplant-in-india" sub="1"><span style="color: #000000;
    font-weight: 700;">Beard Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/eyebrow-transplant-in-india" sub="1"><span style="color: #000000;
    font-weight: 700;">Eyebrow Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/hair-transplant-for-women-in-india" sub="1"><span style="color: #000000;
    font-weight: 700;">Women Hair Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/hair-transplant-for-mens" sub="1"><span style="color: #000000;
    font-weight: 700;">Men Hair Transplant</span></a></li>

                                                                                                                                        </ul>
                                                            </li>                                                                                    <li id="Men_Hair_Transplant"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/hair-transplant-for-mens" sub="1"><span>  Men Hair Transplant                                                 </span></a>                                 

                                                                                                                                                                          <span class="monaka-menu-arrow monaka-submenu-open"></span>

                                                                    <ul style="display: revert;">
                                                                                                                                                 <li  class="monaka-menu-item"> <a href="services_detail/best-hair-transplant-clinic-in-punjab" sub="1"><span style="color: #000000;
    font-weight: 700;">Hair Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/beard-transplant-in-india" sub="1"><span style="color: #000000;
    font-weight: 700;">Beard Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/eyebrow-transplant-in-india" sub="1"><span style="color: #000000;
    font-weight: 700;">Eyebrow Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/hair-transplant-for-women-in-india" sub="1"><span style="color: #000000;
    font-weight: 700;">Women Hair Transplant</span></a></li>

                                                                                                                                                     <li  class="monaka-menu-item"> <a href="services_detail/hair-transplant-for-mens" sub="1"><span style="color: #000000;
    font-weight: 700;">Men Hair Transplant</span></a></li>

                                                                                                                                        </ul>
                                                            </li>                                                            </ul>
                                                            </li>

                                                                

                                                                                    <li class="monaka-menu-item">
                                                                                <a href="javascript:void(0);"> <span style="color: #000000;
    font-weight: 700;">Non Surgical</span><span class="monaka-menu-arrow"></span> </a>
                                                                                <ul>
                                                                                                                                                                        <li id="Dermal_Fillers"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/dermal-filler-treatment-in-india" sub="14"><span>  Dermal Fillers                                                 </span></a>                                 

                                                                                                                                                                                          <li id="Thread_Lift"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/thread-lift-treatment-in-india" sub="15"><span>  Thread Lift                                                 </span></a>                                 

                                                                                                                                                                                          <li id="Chemical_Peels"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/chemical-peel-treatment-in-india" sub="16"><span>  Chemical Peels                                                 </span></a>                                 

                                                                                                                                                                                          <li id="PRP_(Hair)"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/plasma-hair-treatment" sub="17"><span>  PRP (Hair)                                                 </span></a>                                 

                                                                                                                                                                                          <li id="PRP_(Face)"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/plasma-face-treatment" sub="18"><span>  PRP (Face)                                                 </span></a>                                 

                                                                                                                                                                                          <li id="Mesotherapy_for_Face"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/mesotherapy-face-treatment" sub="21"><span>  Mesotherapy for Face                                                 </span></a>                                 

                                                                                                                                                                                          <li id="Mesotherapy_for_Hair"  class="monaka-menu-item" style=" font-weight: 700;">                                                                                      <a href="services_detail/mesotherapy-hair-treatment" sub="22"><span>  Mesotherapy for Hair                                                 </span></a>                                 

                                                                                                                                                                  </ul>
                                                            </li>

                                                                
                                           </ul>
                                        </li> 

                                        <li class="monaka-menu-item ">
                                            <a href="#"><i class="fas fa-comment-dots"></i> <span>Result</span> <span class="monaka-menu-arrow"></span></a>

                                            <ul>
                                                <li class="monaka-menu-item monaka-submenu-right">
                                            <a href="media-events"> <span>Media-Events</span> </a>
                                        </li>
                                        <li class="monaka-menu-item monaka-submenu-right">
                                            <a href="gallery"> <span>Gallery</span> </a>
                                        </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>&nbsp;&nbsp;
  <li class="gapple">
                                     <a href="https://www.goldenaesthetics.in/" class="logo">
                              &nbsp;&nbsp; <img src="logo/black.png" alt="LOGO"  style="width: 73px;"/>
                            </a></li>
                                <li>
                                    
                                    <ul>
                                        <li class="monaka-menu-item monaka-item-mega-menu">
                                            <a href="before-after"> <span>Before / After</span> </a>
                                        </li>
                                        <!-- <li class="monaka-menu-item ">
                                            <a href="#"><i class="fas fa-comment-dots"></i> <span>Cost</span> <span class="monaka-menu-arrow"></span></a>
                                            <ul>
                                                <li class="monaka-menu-item monaka-submenu-right">
                                            <a href="hair-transplant-cost-in-punjab.php"> <span>Hair Transplant Cost Punjab</span> </a>
                                        </li>
                                      
                                            </ul>


                                        </li> -->
                                        <li class="monaka-menu-item monaka-submenu-right">
                                            <a href="medical-tourism"> <span>Medical Tourism</span> </a>
                                        </li>
                                          <!-- <li class="monaka-menu-item monaka-submenu-right">
                                            <a href="media-events.php"> <span>Media-Events</span> </a>
                                        </li> -->
                                        <li class="monaka-menu-item monaka-submenu-right">
                                            <a href="blog"> <span>Blog</span> </a>
                                        </li>
                                        <li class="monaka-menu-item monaka-submenu-right">
                                            <a href="contact-us"> <span>Contact</span> </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </nav>
                        <div class="monaka-menu-search monaka-flex monaka-align-middle">
                            <div class="monaka-menu-toggler">
                                        <label for="MONAKA-NAV">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                                <path d="M3 18h12v-2H3v2zM3 6v2h18V6H3zm0 7h18v-2H3v2z"></path>
                                                <path fill="none" d="M0 0h24v24H0V0z"></path>
                                            </svg>
                                        </label>
                                    </div>
                        </div>
                        <!-- MONAKA MENU END -->
                    </div>
                </div>

                <div class="monaka-header-shadow"></div>
            </header><style type="text/css">
    .readmore:hover {
        font-weight: 900;
        float: right;
        color: #000000 !important;
        background: #fdd101;
        padding: 5px;
        border-radius: 5px;
        font-style: bold;
    }
    .aboutus {
        padding: 90px 20px;
        background-image: url(images/contactbg.png);
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;
    }

    .bottom {
        padding: 90px 20px;
        background-image: url(images/goldenbg.png);
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;
        /*  background: #fdd101;*/
    }
    .blog-image {
        padding-right: 20px;
        width: 117%;
        height: 100%;
    }
    .blog-title {
        /* padding-left: 30px;
    font-size: 20px;*/
        font-weight: bold;
        color: #002c56;
    }

    .blog-text {
        padding-left: 30px;
        font-size: 14px;
        color: #9ba1a9;
    }

    .blog-content {
        padding-left: 56px;
        background: #fff;
        box-shadow: 0 0 10px rgb(0 0 0 / 10%);

        margin: 0px;
    }
    .blog-date {
        font-size: 12px;
        font-weight: bold;
        color: #002c56;

        display: inline-block;
        float: left;
    }
    .readmore {
        float: right;
        color: #002c56 !important;
        background: #fdd101;
        padding: 5px;
        border-radius: 5px;
    }
    .goldhead {
        font-size: 46px;
        color: #002b55;
        font-weight: bold;
        text-align: center;
        /* padding: 20px; */
        margin-bottom: 50px;
    }
    .contact {
        color: #002b55;
        font-size: 14px;
        border: 2px solid #002b55;
        padding: 12px 40px;
        border-radius: 4px;
    }

    .heading {
        padding: 110px 0px 0px 0px;
        color: #000000;
        font-weight: bold;
        text-transform: uppercase;
    }
    .headings {
        padding: 10px 0px 0px 4px;
        color: #000000;
        font-weight: bold;
        text-transform: uppercase;
    }
    @media only screen and (min-device-width: 360px) and (max-device-width: 480px) {
        .headings {
            padding: 10px 0px 0px 0px;
            color: #000000;
            font-weight: bold;
            text-transform: uppercase;
        }
    }
</style>

<section class="aboutus">
    <!-- 	<div class="monaka-header-spacer"></div>
             MONAKA HEADER END 
            <div class="swiper-container home-banner">
                 Additional required wrapper
                <div class="swiper-wrapper">
 Slides 
                    <div class="swiper-slide"><img src="images/aboutbg.png" class="w-100" alt="" /></div>
                </div>
            </div> -->
    <div class="row gx-0">
        <div class="col-md-12">
            <center><h2 class="heading" style="font-size: 1.5rem;"></h2></center>
            <h6 class="headings text-center text-uppercase"><a href="https://www.goldenaesthetics.in/" style="color: #002b55 !important;">HOME </a>| <span style="color: #ffa500;"> BLOG</span></h6>
        </div>
    </div>
</section>

<section>
    <div class="container p-5">
        <div class="row">
            <div class="col-12">
                <h1 class="title text-capitalize mb-4">latest Blog</h1>

                <p class="text-center" style="color: #000000; line-height: 30px;">
                    Catch out the latest blogs by Golden Aesthetics and know<br />
                    the popular trends in the plastic, cosmetic and reconstructive surgery
                </p>
            </div>
        </div>

        <div class="row">
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/Thread Lift Treatment in India.jpeg" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">Give Your Skin a Youthful Look With Thread Lift Treatment in India</h5>

                        <p class="blog-date">2023-01-17</p>
                        <a href="blog-detail/give-your-skin-a-youthful-look-with-thread-lift-treatment-in-india" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/Body Contouring Surgery in India.jpeg" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">Remove The Unwanted Skin with Body Contouring Surgery in India</h5>

                        <p class="blog-date">2022-12-25</p>
                        <a href="blog-detail/remove-the-unwanted-skin-with-body-contouring-surgery-in-india" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/PRP Hair Treatment.jpg" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">Consult Dr. Harkirandeep Singh for the Best PRP Hair Treatment in India</h5>

                        <p class="blog-date">2022-12-05</p>
                        <a href="blog-detail/consult-dr-Harkirandeep-singh-for-the-best-prp-hair-treatment-in-india" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/Beard Transplant in Amritsar.jpg" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">Get a Well - Defined Face Look with Beard Transplant in Amritsar</h5>

                        <p class="blog-date">2022-10-18</p>
                        <a href="blog-detail/get-a-well-defined-face-look-with-beard-trasnplant-in-amritsar" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/Hair Fall Treatment.jpeg" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">Guide To Get Effective Solutions For Hair Fall Treatment In Amritsar</h5>

                        <p class="blog-date">2022-08-09</p>
                        <a href="blog-detail/guide-to-get-effective-solutions-for-hair-fall-treatment-in-amritsar" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/hair transplant doctor in india.jpeg" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">Get Extensive Hair Revision by the Best Hair Transplant Doctor in India</h5>

                        <p class="blog-date">2022-07-17</p>
                        <a href="blog-detail/get-extensive-hair-revision-by-the-best-hair-transplant-doctor-in-india" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/Plastic Surgeon.jpeg" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">How does the Best Plastic Surgeon in Amritsar Help You Get the Beautiful You?</h5>

                        <p class="blog-date">2022-03-08</p>
                        <a href="blog-detail/how-does-the-best-plastic-surgeon-in-amritsar-help-you-get-the-beatiful-you" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/BeardTransplant.jpg" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">13 Things to Know about Beard Transplant to Get a Perfect Before and After Look</h5>

                        <p class="blog-date">2022-02-28</p>
                        <a href="blog-detail/13-things-to-know-about-beard-transplant-to-get-a-perfect-before-and-after-look" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/hymen-min.png" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">11 Things You Need to Know about Hymen Repair in India</h5>

                        <p class="blog-date">2022-02-09</p>
                        <a href="blog-detail/11-things-you-need-to-know-about-hymen-repair-in-india" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/Rhinoplasty.jpg" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">Know These Important Things Before Getting The Best Rhinoplasty Surgery In India</h5>

                        <p class="blog-date">2022-01-05</p>
                        <a href="blog-detail/know-these-important-things-before-getting-the-best-rhinoplasty-surgery-in-india" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/Hair fall.jpg" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">Hair Fall In Men and Women</h5>

                        <p class="blog-date">2021-12-17</p>
                        <a href="blog-detail/hair-fall-in-men-and-women" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/diabetic.jpg" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">Is Hair Transplant realizable for diabetic people?</h5>

                        <p class="blog-date">2021-11-07</p>
                        <a href="blog-detail/is-hair-transplant-realizable-for-diabetic-people" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/B-1.jpg" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">Things To Consider Before Having a Hair Transplant</h5>

                        <p class="blog-date">2021-10-31</p>
                        <a href="blog-detail/things-to-consider-before-having-a-hair-transplant" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/B-1-min.jpg" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">Chest Implants For Men - What You Need To Know</h5>

                        <p class="blog-date">2021-10-28</p>
                        <a href="blog-detail/chest-implants-for-men-what-you-need-to-know" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/shape.jpg" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">Ways You Can Reshape Your Ears</h5>

                        <p class="blog-date">2021-10-18</p>
                        <a href="blog-detail/ways-you-can-reshape-your-ears" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/feature-image.png" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">Trust Golden Aesthetics For The Latest Hair Gain Therapies</h5>

                        <p class="blog-date">2021-09-08</p>
                        <a href="blog-detail/trust-golden-aesthetics-for-the-latest-hair-gain-therapies" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/Main-Image.jpg" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">What you need to know about your tummy tuck recovery</h5>

                        <p class="blog-date">2021-08-25</p>
                        <a href="blog-detail/know-about-your-tummy-tuck-recovery" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/10 myths.jpg" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">10 Myths about Hair Transplant </h5>

                        <p class="blog-date">2021-08-23</p>
                        <a href="blog-detail/10-myths-about-hair-transplant" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/Main-Image (1) (1).jpg" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">Liposuction surgery everything you want to know</h5>

                        <p class="blog-date">2021-08-09</p>
                        <a href="blog-detail/liposuction-surgery-everything-you-want-to-know" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/Feature-Imags.png" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">Does PRP treatment for the face really work for wrinkles?</h5>

                        <p class="blog-date">2021-08-06</p>
                        <a href="blog-detail/does-prp-treatment-for-the-face-really-work-for-wrinkles" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                        <div class="col-md-4 p-4">
                <div class="row">
                    <div class="blog-content p-4">
                        <img src="uploads/blogimages/2.jpg" style="width: 100%; padding-bottom: 18px;" /><br />
                        <h5 class="blog-title" style="font-size: 17px;">Suffering from baldness? Here’s all you need to know about the Procedure of Hair Transplant!</h5>

                        <p class="blog-date">2021-07-04</p>
                        <a href="blog-detail/suffering-from-baldness-here-all-you-need-to-know-about-the-procedure-of-hair-transplant" class="readmore">
                            Read More
                            <!--<img src="images/readmore.png">-->
                        </a>
                    </div>
                </div>
            </div>
                    </div>
    </div>
</section>

<!--	<section class="bottom pt-5">

		<div class="container p-5">

			<center>
				
				<h1 class="goldhead">
					#1 Hair Transplant Clinic <br> In Amritsar 
				</h1>

				<a href="contact.php" class="contact">
					
					CONTACT NOW
				</a>
			</center>
			
		</div>


	</section>-->

<style>
    .whats-app {
    position: fixed;
    color: #25d366;
    border-radius: 50px;
    font-size: 23px;
    right: 15px;
    bottom: 96px;
    z-index: 100;
    margin-left: 5px;
}
.whats-app2 {
    position: fixed;
    width: 138px;
    height: 38px;
    color: #25d366;
    border-radius: 50px;
    font-size: 23px;
    right: -62px;
    z-index: 100;
    margin-left: 5px;
    bottom: 186px;
}
</style>
  <section class="footer py-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-3">
                        <img src="images/logo.png" alt="">
                        <p class="mt-3 about-para text-white text-justify">
                            We, at Golden Aesthetics-the Best Plastic Surgery Hospital in India, ensure to meet the hygiene and safety standards providing quality service to our current patients and future clients. 

                        </p>
                        <div class="address mt-3">
                            <div class="address-icon"><span class="icon"><ion-icon name="location-outline"></ion-icon></span></div>
                            <div class="address-text"><p class='text-white'> Above  Charming Chicken, Majitha Rd, Sehaj Avenue, Amritsar, Punjab 143001</p> </div>
                        </div>
                          
                              
                        
                        
                    </div>
                    <div class="col-md-1"></div>
                    <div class="col-md-5">
                        <h5 class="text-white">Our Services</h5>
                        <ul class="list-unstyled service-list">
                            <li><a href="https://www.goldenaesthetics.in/services_detail/best-hair-transplant-clinic-in-punjab" class="text-white">Hair Transplant</a></li>
                            <li><a href="https://www.goldenaesthetics.in/services_detail/face-lift-plastic-surgery-in-india" class="text-white">Face Lift Surgery</a></li>
                            <li><a href="https://www.goldenaesthetics.in/services_detail/face-split-earlobe-repair-in-india" class="text-white">Auroplasty</a></li>
                            <li><a href="https://www.goldenaesthetics.in/services_detail/dimple-creation-in-india" class="text-white">Dimple Creation</a></li>
                            <li><a href="https://www.goldenaesthetics.in/services_detail/nose-plastic-surgery-in-india" class="text-white">Rhinoplasty</a></li>
                            <li><a href="https://www.goldenaesthetics.in/services_detail/eyelid-plastic-surgery" class="text-white">Eye-lid Surgery</a></li>
                            <li><a href="https://www.goldenaesthetics.in/services_detail/body-contouring-surgery-in-india" class="text-white">Body Contouring</a></li>
                            <li><a href="https://www.goldenaesthetics.in/services_detail/best-gynecomastia-surgery-in-india" class="text-white">Gynaecomastia</a></li>
                            <li><a href="https://www.goldenaesthetics.in/services_detail/best-liposuction-surgery-in-india" class="text-white">Liposuction</a></li>
                            <li><a href="https://www.goldenaesthetics.in/services_detail/tummy-tuck-in-india" class="text-white">Tummy Tuck</a></li>
                            <li><a href="https://www.goldenaesthetics.in/services_detail/otoplasty-surgery-in-india" class="text-white">Otoplasty</a></li>
                        </ul>
                    </div>
                     
                    <div class="col-md-3">
                       <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fgoldenaestheticsamritsar&tabs=timeline&width=340&height=300&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="300" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <ul class="list-unstyled three-box">
                            <li>
                                <div class="icon">
                                    <span><ion-icon name="mail-open-outline"></ion-icon></span>
                                </div>
                                <div class="text">
                                    <p class="fw-bold text-white mb-0">goldenaesthetics999@gmail.com</p>
                                    <p class="text-white"><small>Drop us a line</small></p>
                                </div>
                            </li>
                            <li class="active">
                                <div class="icon">
                                    <span><ion-icon name="call-outline"></ion-icon></span>
                                </div>
                                <div class="text">
                                    <p class="fw-bold text-white mb-0">+91 80 70 500 900</p>
                                    <p class="text-white"><small>Call us Now</small></p>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <span><ion-icon name="time-outline"></ion-icon></span>
                                </div>
                                <div class="text">
                                    <p class="fw-bold text-white mb-0">09:30 AM - 07:30 PM</p>
                                    <p class="text-white"><small>Working Hours</small></p>
                                </div>
                            </li>
                             
                        </ul>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row g-3 mt-4">
                    <div class="col-md-5 text-white text-center text-md-left"> <p class="text-white">Copyright &copy; 2021 Golden Aesthetics All Rights Reserved</p></div>
                    <div class="col-md-2">
                        <ul class="list-unstyled d-flex justify-content-center">
                            <li class="p-2"><a href="https://www.facebook.com/goldenaestheticsamritsar/" class="h3 text-white" target='_blank'><ion-icon name="logo-facebook"></ion-icon></a></li>
                            <li class="p-2"><a href="https://www.instagram.com/goldenaestheticsamritsar/" class="h3 text-white" target='_blank'><ion-icon name="logo-instagram"></ion-icon></a></li>
                            <li class="p-2"><a href="https://api.whatsapp.com/send?phone=+918070500900&text=Hi%20Golden%20 Aesthetics%20,%20I%20want%20Connect%20With%20You" class="h3 text-white" target='_blank'><ion-icon name="logo-whatsapp"></ion-icon></a></li>
                        </ul>
                    </div>
                    <div class="col-md-5">
                            <p class="text-white text-center  text-md-right">Privacy Policy <a href="http://www.g/" ><br>Privacy Policy</a></p>
                    </div>
                </div>
            </div>
        </section>
        <ul>
      <li style='list-style:none'>  <a class="whats-app" href="https://api.whatsapp.com/send?phone=+918070500900&text=Hi%20Golden%20 Aesthetics%20,%20I%20want%20Connect%20With%20You" target="_blank">
    <img src='whats.webp' style='height: 60px;'></a></i>
</a>
</li>
<li style='list-style:none'>  <a class="whats-app2" href="tel:+918070500900">
    <img src='pone.webp' style='height: 60px;'>
</a>
</li>
  </ul>
       
       
        <style>
        
        @media only screen 
and (min-device-width : 360px)   
and (max-device-width : 480px)  
{ 
    .emergency {
   
    padding-top: 50px !important; 

  
}
    .whats-app {
  
    bottom: 141px !important; 

}
.whats-app2 {
   
    bottom: 228px !important;
}
   .footer .three-box li {
    width: 100%;
    float: left;
    display: block;
    padding: 15px 10px;
    background-color: #0e0c21;
    
    
}



#myBtn {
    width: 11%;
    display: none;
    position: fixed;
    bottom: 90px;
    right: 30px;
    z-index: 9999;
    font-size: 18px;
    border: 2 px solid #f4ca01;
    outline: none;
    background-color: #f4ca01;
    color: white;
    cursor: pointer;
    padding: 7px;
    border-radius: 26px;
}
}</style>
<script>
//Get the button
var mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>


<style>
    @media only screen 
and (min-device-width : 360px)   
and (max-device-width : 480px)  
{ 


.nik
    {
        margin-top: 52px;
    margin-bottom: -5px;
    }
}
 @media only screen 
and (min-device-width : 1370px)   
and (max-device-width : 1650px)  
{ 
    
   
  
.nik
    {
        margin-bottom:0px;
    }

}
   
@media only screen 
and (min-device-width : 512px)   
and (max-device-width : 1422px)  
{ 
    
    .nik
    {
        margin-bottom:17px;
    }
   
     
}


</style>
         <script src="js/monaka.js"></script><script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
<script type='text/javascript'>
(function(I, L, T, i, c, k, s) {if(I.iticks) return;I.iticks = {host:c, settings:s, clientId:k, cdn:L, queue:[]};var h = T.head || T.documentElement;var e = T.createElement(i);var l = I.location;e.async = true;e.src = (L||c)+'/client/inject-v2.min.js';h.insertBefore(e, h.firstChild);I.iticks.call = function(a, b) {I.iticks.queue.push([a, b]);};})(window, 'https://cdn.intelliticks.com/prod/common', document, 'script', 'https://app.intelliticks.com', 'xQBXxsBSAHWG7rKtu_c', {});
</script>
    </body>
</html>
